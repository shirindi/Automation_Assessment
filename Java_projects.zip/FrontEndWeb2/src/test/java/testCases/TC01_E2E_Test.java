package testCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import pages.AddProductToCart;
import pages.LoginPage;

public class TC01_E2E_Test {
	
	static WebDriver driver;
	
	@BeforeTest
	public void setUp() {
		ChromeOptions option = new ChromeOptions();
        option.addArguments("--remote-allow-origins=*");
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver(option);
		driver.get("https://www.saucedemo.com/inventory.html");
		driver.manage().window().maximize();
		
	}

	@Test (priority=1)
	public void loginTest() throws Exception {
		LoginPage page = new LoginPage(driver);
		page.enterUn();
		page.enterPw();
		page.clickBtn();
		page.validateHomePage();
		
	}
	
	@Test (priority=2)
	public void addProductCart1() throws Exception{
		AddProductToCart click = new AddProductToCart(driver);
		click.clickBtn1();
	}
	
	@Test (priority=3)
	public void addproductcart2() throws Exception{
		AddProductToCart click2 = new AddProductToCart(driver);
		click2.clickBtn2();
	}
	
	@Test (priority=4)
	public void addproductcart3() throws Exception{
		AddProductToCart click3 = new AddProductToCart(driver);
		click3.clickBtn3();
	}
	
	@Test (priority=5)
	public void addproductcart4() throws Exception{
		AddProductToCart click4 = new AddProductToCart(driver);
		click4.clickBtn4();
		click4.validateProduct1();
	}
	
	public void tearDown() {
		driver.quit();
		
	}
}
