package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class AddProductToCart {
	WebDriver driver;
	public AddProductToCart(WebDriver driver) {
	    this.driver = driver;
		
	}
	
	By clickBtn1 = By.id("add-to-cart-sauce-labs-backpack");
	By clickBtn2 = By.id("add-to-cart-sauce-labs-bolt-t-shirt");
	By clickBtn3 = By.id("add-to-cart-sauce-labs-bike-light");
	By clickBtn4 = By.id("add-to-cart-sauce-labs-fleece-jacket");
	By clickBtn5 = By.id("shopping_cart_container");
	
	
    public void clickBtn1() throws Exception {
		
		driver.findElement(clickBtn1).click();
		Thread.sleep(4000);
	}
    
    public void clickBtn2() throws Exception {
		
		driver.findElement(clickBtn2).click();
		Thread.sleep(4000);
	}
    
    public void clickBtn3() throws Exception {
		
		driver.findElement(clickBtn3).click();
		Thread.sleep(4000);
	}
    
    public void clickBtn4() throws Exception {
		
		driver.findElement(clickBtn4).click();
		Thread.sleep(4000);
	}
    
    public void clickBtn5() throws Exception {
    	
    	driver.findElement(clickBtn5).click();
		Thread.sleep(4000);
    }
    
    public void validateProduct1() {
    	driver.findElement(clickBtn5).click();
    }
}
